<footer class="page-footer blue center-on-small-only">
    <p>
        Sitio web creado por Mariale_263
    </p>
    <a class="btn btn-social-icon  btn-instagram" href="https://www.instagram.com/mariale_263/">
        <span class = "fa fa-instagram fa-2x"> </span>
    </a>
   
    <a class="btn btn-social-icon btn-facebook">
        <span class="fa fa-facebook fa-2x"></span>
    </a>

    <a class="btn btn-social-icon btn-pinterest">
        <span class="fa fa-pinterest fa-2x"></span>
    </a>
    
    
</footer>